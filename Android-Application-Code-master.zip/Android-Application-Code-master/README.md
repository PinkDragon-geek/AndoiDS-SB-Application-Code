# AndroiDS_SB Android-Application-Code 
AndroiDS-SB is an Intrusion Detection System based on signatures for Android mobile . 
The program is concerned with searching for suspicious URLs and Applications
based on the signatures collected from international organizations.
The signature database must always be updated.
